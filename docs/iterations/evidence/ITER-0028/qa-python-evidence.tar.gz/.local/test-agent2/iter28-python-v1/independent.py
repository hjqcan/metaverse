#!/usr/bin/env python3
"""Frozen Python v1 through a real loopback HTTP fault proxy; no SQL grants."""
from contextlib import closing
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
sys.path.insert(0, str(ROOT/'tests'))
import workshop_api as api
sys.path.insert(0, str(BASE/'product/scripts'))
import resident_forestry as forestry
import resident_mission as mission
from foundation_agent import WorldClient

DLL = ROOT/'.local/iter0028/server-v2/World.Server.dll'
api.DLL = DLL
CAPS = 'workshop-v1,forestry-v1'
LEGACY = ROOT/'.local/test-agent2/iter28-source13-20261026T095453Z'
READY = BASE/'ready-source'
RUN = BASE/('run-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
PREFIX = api.PREFIX


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, value):
    Path(p).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


def cold_copy(source, destination):
    """Never open the source: copy cold durable files, then normalize our copy."""
    source, destination = Path(source), Path(destination)
    destination.mkdir(parents=True, mode=0o700, exist_ok=True)
    staging = destination.parent/(destination.name+'-staging')
    staging.mkdir(mode=0o700)
    files = [p for p in source.iterdir() if p.name in ('world.db', 'world.db-wal', 'world.db-journal', 'access.json')]
    before = {p.name: sha(p) for p in files}
    for p in files:
        shutil.copy2(p, staging/p.name)
    if before != {p.name: sha(p) for p in files}:
        raise AssertionError('Cold source changed while copying')
    with closing(api.sqlite3.connect(staging/'world.db')) as src, closing(api.sqlite3.connect(destination/'world.db')) as dst:
        if src.execute('PRAGMA integrity_check').fetchall() != [('ok',)]:
            raise AssertionError('Owned staging copy is malformed; preserve files')
        src.backup(dst)
    shutil.copy2(staging/'access.json', destination/'access.json')
    os.chmod(destination/'access.json', 0o600)
    shutil.rmtree(staging)


def sql_check(data):
    with closing(api.sqlite3.connect(f'file:{Path(data)/"world.db"}?mode=ro', uri=True)) as db:
        result = dict(integrity=db.execute('PRAGMA integrity_check').fetchall(),
                      foreignKeys=db.execute('PRAGMA foreign_key_check').fetchall(),
                      storageVersion=db.execute('PRAGMA user_version').fetchone()[0],
                      stateVersion=db.execute('SELECT state_version FROM worlds').fetchone()[0],
                      receipts=db.execute('SELECT count(*) FROM receipts').fetchone()[0],
                      events=db.execute('SELECT count(*) FROM events').fetchone()[0])
        if result['integrity'] != [('ok',)] or result['foreignKeys']:
            raise AssertionError(result)
        return result


class World(api.World):
    def __init__(self, path, source):
        super().__init__(path)
        self.env.pop('WORLD_SCENARIO', None)
        cold_copy(source, self.data)
        self.access = json.loads((self.data/'access.json').read_text())
        with closing(api.sqlite3.connect(f'file:{self.data/"world.db"}?mode=ro', uri=True)) as db:
            self.instance = db.execute('SELECT instance_id FROM world_instance').fetchone()[0]
            version = db.execute('PRAGMA user_version').fetchone()[0]
        if version == 13:
            result = self.admin('adopt-forestry')
            if result.returncode:
                raise AssertionError(result.stderr)

    def request(self, method, path, payload=None, actor='a3', capability=CAPS, **kwargs):
        return super().request(method, path, payload, actor=actor, capability=capability, **kwargs)


class Proxy:
    """Forward real requests. Record no Authorization header or bearer value."""
    def __init__(self, port):
        self.upstream, self.mode, self.traffic = port, None, []
        self.observations = 0
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                self.relay()

            def do_POST(self):
                self.relay()

            def relay(self):
                raw = self.rfile.read(int(self.headers.get('Content-Length', 0)))
                entry = {'method': self.command, 'path': self.path, 'request': json.loads(raw) if raw else None,
                         'mode': owner.mode, 'atEpoch': time.time(), 'forwarded': False}
                owner.traffic.append(entry)
                is_post = self.command == 'POST'
                if self.path.endswith('/observation'):
                    owner.observations += 1
                    if owner.mode == 'delayed-observation' and owner.observations == 2:
                        time.sleep(2.2)
                if is_post and owner.mode == 'drop-before':
                    owner.mode = None
                    entry['droppedBefore'] = True
                    self.close_connection = True
                    return
                connection = http.client.HTTPConnection('127.0.0.1', owner.upstream, timeout=15)
                try:
                    headers = {k: v for k, v in self.headers.items() if k.lower() not in ('host', 'content-length', 'connection')}
                    connection.request(self.command, self.path, raw if raw else None, headers)
                    response = connection.getresponse()
                    body = response.read()
                    status = response.status
                    instance = response.getheader('World-Instance-Id')
                finally:
                    connection.close()
                entry.update(forwarded=True, upstreamStatus=status, upstreamSha256=hashlib.sha256(body).hexdigest())
                if is_post and owner.mode == 'drop-after':
                    owner.mode = None
                    entry['droppedAfter'] = True
                    self.close_connection = True
                    return
                if '/forestry/actions/' in self.path and owner.mode == 'alter-detail':
                    value = json.loads(body)
                    value['forestryAction']['commandId'] = 'different_original_command'
                    body = json.dumps(value).encode()
                if '/events?' in self.path and owner.mode == 'missing-event':
                    status = 503
                    body = b'{"error":{"code":"QA2_PROXY_EVENT_UNAVAILABLE"}}'
                if '/commands/' in self.path and owner.mode == 'wrong-instance':
                    instance = 'w_'+'0'*32
                if self.path.endswith('/observation') and owner.mode == 'unknown-capability':
                    value = json.loads(body)
                    value['forestry']['version'] = 2
                    body = json.dumps(value).encode()
                entry['returnedStatus'] = status
                self.send_response(status)
                self.send_header('Content-Type', 'application/json')
                if instance:
                    self.send_header('World-Instance-Id', instance)
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = f'http://127.0.0.1:{self.server.server_port}'

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def posts(self, forwarded=False):
        return [r for r in self.traffic if r['method'] == 'POST' and (not forwarded or r['forwarded'])]


def spec(instance, kind='reserve_forest', *, actor='a3', fields=None, target=None, returns=False, seconds=30):
    a = dict(type=kind, capabilityVersion=1, **(fields or {}))
    return dict(missionId='qa2-'+kind, objective='独立核对原林业动作恢复与预算',
                goals=[dict(id='one', label='原动作', target=target,
                            forestry=dict(worldInstanceId=instance, actorId=actor, action=a,
                                          waitForReady=False, returnToOrigin=returns))],
                allowBuild=False, **{p: k == kind for k, p in forestry.PERMISSIONS.items()},
                budgets=dict(commands=100, queries=100, **forestry.costs(a), seconds=seconds, modelCalls=0))


class Checks(unittest.TestCase):
    def setUp(self):
        self.directory = RUN/self._testMethodName
        self.directory.mkdir(parents=True)
        self.world = self.proxy = None
        self.reports = []
        self.addCleanup(self.close)

    def use(self, ready=False, actor='a3'):
        self.actor = actor
        self.world = World(self.directory/'runtime', READY if ready else LEGACY)
        self.initial_sql = sql_check(self.world.data)
        self.world.start()
        self.proxy = Proxy(self.world.port)
        self.client = WorldClient(self.proxy.url, self.world.access['sessions'][actor]['token'])
        self.job = spec(self.world.instance, actor=actor)
        self.state = self.directory/'state.json'
        if ready:
            p = json.loads((READY/'provenance.json').read_text())
            self.job = spec(self.world.instance, 'harvest_tree', actor=actor,
                            fields=dict(plantId=p['plant']['plantId'], reservationId=p['reservationId'], toolId=p['tool']['toolId']),
                            target=forestry.PLOTS[p['plant']['plotId']])
        return self.world

    def close(self):
        if self.world is None:
            return
        record = {'initial': self.initial_sql}
        try:
            if self.world.process and self.world.process.poll() is None:
                record['live'] = sql_check(self.world.data)
                observed = self.world.observe(self.actor)
                record['resourceAudit'], record['seedAudit'] = observed['resourceAudit'], observed['seedAudit']
                self.assertIs(True, observed['resourceAudit']['conserved'])
                self.assertIs(True, observed['seedAudit']['conserved'])
        finally:
            if self.proxy:
                self.proxy.close()
            self.world.stop()
            save(self.directory/'reports.json', self.reports)
            save(self.directory/'proxy-traffic.json', self.proxy.traffic if self.proxy else [])
            save(self.directory/'setup-traffic.json', self.world.trace)
        record['afterStop'] = sql_check(self.world.data)
        save(self.directory/'sql-audit.json', record)

    def task(self):
        def forbidden(*args, **kwargs):
            raise AssertionError('No selector or model may be called')
        result = mission.run_mission(self.client, self.job, self.state, forbidden)
        self.reports.append(deepcopy(result))
        forestry.validate_saved(json.loads(self.state.read_text()), self.job, dict(url=self.client.url, prefix=self.client.prefix))
        self.assertEqual(0, result['budget']['used']['modelCalls'])
        return result

    def pending(self):
        return json.loads(self.state.read_text())['_state']['pending']

    def complete(self, result):
        self.assertEqual('completed', result['mission']['status'], result['mission'])
        self.assertTrue(result['facts']['forestryCompleted'])
        self.assertIsNone(self.pending())
        self.assertEqual(result['budget']['used']['queries'], sum(t['method'] == 'GET' for t in self.proxy.traffic))
        return result['facts']['forestryAction']

    def test_01_request_not_forwarded_original_404_resends_once(self):
        self.use()
        self.proxy.mode = 'drop-before'
        self.assertEqual('unknown', self.task()['mission']['status'])
        pending = self.pending()
        self.assertEqual(0, len(self.proxy.posts(forwarded=True)))
        d = self.complete(self.task())
        self.assertEqual(pending['request']['commandId'], d['commandId'])
        self.assertEqual([pending['request'], pending['request']], [r['request'] for r in self.proxy.posts()])
        self.assertEqual(1, len(self.proxy.posts(forwarded=True)))

    def test_02_committed_harvest_response_lost_recovers_no_post(self):
        self.use(ready=True)
        self.proxy.mode = 'drop-after'
        self.assertEqual('unknown', self.task()['mission']['status'])
        original = self.pending()
        self.assertEqual(1, len(self.proxy.posts(forwarded=True)))
        d = self.complete(self.task())
        self.assertEqual(original['request']['commandId'], d['commandId'])
        self.assertEqual(1, len(self.proxy.posts()))
        self.assertEqual((0, 3, 0, 1), tuple(d[k] for k in ('inventoryWoodBefore', 'inventoryWood', 'seedsBefore', 'seeds')))

    def test_03_altered_detail_cannot_settle_original(self):
        self.use()
        self.proxy.mode = 'alter-detail'
        report = self.task()
        self.assertEqual('unknown', report['mission']['status'])
        self.assertFalse(report['facts']['forestryCompleted'])
        original = self.pending()
        self.proxy.mode = None
        d = self.complete(self.task())
        self.assertEqual(original['request']['commandId'], d['commandId'])
        self.assertEqual(1, len(self.proxy.posts()))

    def test_04_missing_event_cannot_settle_original(self):
        self.use()
        self.proxy.mode = 'missing-event'
        self.assertEqual('unknown', self.task()['mission']['status'])
        original = self.pending()
        self.proxy.mode = None
        d = self.complete(self.task())
        self.assertEqual(original['request']['commandId'], d['commandId'])
        self.assertEqual(1, len(self.proxy.posts()))

    def test_05_wrong_instance_recovery_retains_exact_pending(self):
        self.use()
        self.proxy.mode = 'drop-before'
        self.task()
        original = self.pending()
        self.proxy.mode = 'wrong-instance'
        self.assertEqual('unknown', self.task()['mission']['status'])
        self.assertEqual(original, self.pending())
        self.assertEqual(0, len(self.proxy.posts(forwarded=True)))
        self.proxy.mode = None
        self.complete(self.task())
        self.assertEqual(1, len(self.proxy.posts(forwarded=True)))

    def test_06_unknown_capability_after_404_does_not_resend(self):
        self.use()
        self.proxy.mode = 'drop-before'
        self.task()
        original = self.pending()
        self.proxy.mode = 'unknown-capability'
        self.assertEqual('unknown', self.task()['mission']['status'])
        self.assertEqual(original, self.pending())
        self.assertEqual(0, len(self.proxy.posts(forwarded=True)))
        self.proxy.mode = None
        self.complete(self.task())

    def test_07_corrupted_pending_rejected_before_network_without_overwrite(self):
        self.use()
        self.proxy.mode = 'drop-before'
        self.task()
        good = self.state.read_bytes()
        corrupted = json.loads(good)
        corrupted['_state']['pending']['request']['commandId'] = 'substituted_original_command'
        save(self.state, corrupted)
        bad = self.state.read_bytes()
        calls = len(self.proxy.traffic)
        with self.assertRaises(ValueError):
            self.task()
        self.assertEqual(bad, self.state.read_bytes())
        self.assertEqual(calls, len(self.proxy.traffic))
        self.state.write_bytes(good)
        self.complete(self.task())

    def test_08_observation_crosses_deadline_zero_post(self):
        self.use()
        self.job['budgets']['seconds'] = 2
        self.proxy.mode = 'delayed-observation'
        result = self.task()
        self.assertEqual('budget_exhausted', result['mission']['status'])
        self.assertGreaterEqual(result['budget']['used']['seconds'], 2)
        self.assertEqual([], self.proxy.posts())

    def test_09_final_fresh_save_crosses_deadline_zero_post_exact_pending(self):
        self.use()
        self.job['budgets']['seconds'] = 2
        original_save = mission._save
        seen = []
        def delayed(path, state):
            original_save(path, state)
            if state.get('_state', {}).get('pending') is not None:
                seen.append(deepcopy(state['_state']['pending']))
                if len(seen) == 2:
                    time.sleep(2.2)
        with patch.object(mission, '_save', delayed):
            report = self.task()
        self.assertEqual('budget_exhausted', report['mission']['status'])
        self.assertEqual([], self.proxy.posts())
        self.assertGreaterEqual(len(seen), 2)
        self.assertEqual(seen[0], self.pending())
        self.assertEqual(1, report['budget']['used']['commands'])
        save(self.directory/'last-save-probe.json', dict(delayedPending=seen[1], seconds=report['budget']['used']['seconds'], postCount=0))

    def test_10_final_recovery_save_crosses_deadline_zero_resend(self):
        self.use()
        self.job['budgets']['seconds'] = 2
        self.proxy.mode = 'drop-before'
        self.task()
        pending = self.pending()
        original_save = mission._save
        writes = []
        def delayed(path, state):
            original_save(path, state)
            receipt_seen = any('/commands/' in t['path'] and t.get('upstreamStatus') == 404 for t in self.proxy.traffic)
            latest_observation = self.proxy.traffic and self.proxy.traffic[-1]['path'].endswith('/observation')
            if receipt_seen and latest_observation and state.get('_state', {}).get('pending') is not None:
                writes.append(deepcopy(state['_state']['pending']))
                if len(writes) == 2:
                    time.sleep(2.2)
        with patch.object(mission, '_save', delayed):
            result = self.task()
        self.assertEqual('budget_exhausted', result['mission']['status'])
        self.assertGreaterEqual(len(writes), 2)
        self.assertEqual(pending, self.pending())
        self.assertEqual(1, len(self.proxy.posts()))
        self.assertEqual(0, len(self.proxy.posts(forwarded=True)))
        self.assertEqual(1, result['budget']['used']['commands'])
        save(self.directory/'last-save-probe.json', dict(originalPending=pending, seconds=result['budget']['used']['seconds'], resendCount=0))

    def test_11_cli_no_return_is_false_and_terminal_replay_no_network(self):
        w = self.use()
        observed = w.observe('a3')
        bench = next(e for e in observed['entities'] if e['definitionId'] == 'workbench' and e['ownerActorId'] == 'a2')
        self.job = spec(w.instance, 'craft_forestry_tool', fields=dict(entityId=bench['entityId'], recipeId='wooden_axe.v1'), target=bench['position'])
        job = self.directory/'job.json'; output = self.directory/'cli-report.json'
        save(job, self.job)
        command = [sys.executable, str(BASE/'product/scripts/run_resident.py'), '--url', self.proxy.url,
                   '--access-file', str(w.data/'access.json'), '--actor', 'a3', '--spec', str(job),
                   '--state', str(self.state), '--output', str(output)]
        process = subprocess.run(command, capture_output=True, text=True, timeout=40, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        save(self.directory/'cli-result.json', dict(returncode=process.returncode, stdout=process.stdout, stderr=process.stderr))
        self.assertEqual(0, process.returncode, process.stderr)
        result = json.loads(output.read_text()); self.reports.append(result)
        self.complete(result)
        self.assertFalse(result['facts']['returned'])
        self.assertGreater(api.math.dist(w.observe('a3')['self']['position'], result['mission']['origin']), .06)
        requests = len(self.proxy.traffic)
        rerun = subprocess.run(command, capture_output=True, text=True, timeout=10, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        self.assertEqual(0, rerun.returncode, rerun.stderr)
        self.assertEqual(requests, len(self.proxy.traffic))
        self.assertEqual(result, json.loads(output.read_text()))

    def test_12_requested_return_requires_actual_walk_back(self):
        w = self.use()
        observed = w.observe('a3')
        bench = next(e for e in observed['entities'] if e['definitionId'] == 'workbench' and e['ownerActorId'] == 'a2')
        self.job = spec(w.instance, 'craft_forestry_tool', fields=dict(entityId=bench['entityId'], recipeId='wooden_axe.v1'), target=bench['position'], returns=True)
        result = self.task()
        self.complete(result)
        self.assertTrue(result['facts']['returned'])
        self.assertLessEqual(api.math.dist(w.observe('a3')['self']['position'], result['mission']['origin']), .06)
        self.assertTrue(any(s['reason'] == '返回原起点' and s['status'] == 'committed' for s in result['steps']))

    def test_13_original_harvest_recovers_after_new_generation_exists(self):
        w = self.use(ready=True)
        self.proxy.mode = 'drop-after'
        self.task()
        pending = self.pending()
        old_plant = pending['request']['action']['plantId']
        _, response = w.send(dict(type='reserve_forest', capabilityVersion=1), 'a3')
        rid = response[1]['result']['forestryAction']['reservation']['reservationId']
        deadline = time.monotonic()+5
        reservation = None
        while time.monotonic() < deadline:
            reservation = next((r for r in w.observe('a3')['forestry']['reservations'] if r['reservationId'] == rid and r['status'] == 'preparing'), None)
            if reservation:
                break
            time.sleep(.1)
        self.assertIsNotNone(reservation)
        _, response = w.send(dict(type='plant_tree', capabilityVersion=1, reservationId=rid, plotId=reservation['plotId']), 'a3')
        second = response[1]['result']['forestryAction']['plant']
        self.assertNotEqual(old_plant, second['plantId'])
        record = self.complete(self.task())
        self.assertEqual(old_plant, record['plant']['plantId'])
        self.assertEqual(1, len(self.proxy.posts()))
        observed = w.observe('a3')
        self.assertEqual([second], observed['forestry']['plants'])
        self.assertEqual((3, 0), tuple(observed['resourceAudit'][k] for k in ('forestGeneratedWood', 'standingForestWood')))
        self.assertEqual(0, observed['forestry']['seeds'])


def main():
    RUN.mkdir(parents=True, mode=0o700)
    frozen = json.loads((BASE/'candidate.json').read_text())
    for name, value in frozen['codeHashes'].items():
        assert sha(BASE/'product'/name) == value, name
    assert sha(DLL) == frozen['backendSha256']
    save(RUN/'candidate.json', dict(product=frozen, probeSha256=sha(__file__), actualModelCalls=0))
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Checks) if len(sys.argv) == 1 else unittest.TestSuite(Checks(name) for name in sys.argv[1:])
    with (RUN/'test.log').open('w') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=api.EvidenceResult).run(suite)
    failed = {str(t).split(' ')[0] for t, _ in result.failures+result.errors}
    removed, retained = 0, []
    for path in RUN.glob('test_*/runtime'):
        if path.parent.name in failed:
            retained.append(str(path))
        else:
            removed += sum(p.stat().st_size for p in path.rglob('*') if p.is_file())
            shutil.rmtree(path)
    report = dict(passed=result.wasSuccessful(), testsRun=result.testsRun, tests=result.records,
                  failures=[(str(t), error) for t, error in result.failures+result.errors],
                  actualModelCalls=0, disposedRuntimeBytes=removed, retainedFailedRuntime=retained,
                  productHashes=frozen['codeHashes'], backendSha256=sha(DLL), probeSha256=sha(__file__))
    save(RUN/'results.json', report)
    print(json.dumps(dict(passed=report['passed'], testsRun=result.testsRun, results=str(RUN/'results.json')), ensure_ascii=False))
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())
